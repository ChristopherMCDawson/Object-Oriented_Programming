
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;//scanner import

/**
 * College class to ask for input and setup menu formating for the main and the the last outputs as well as holding an Arraylist of students and their details.
 * 
 *@author Christopher Decarie-Dawson
 *@version 2.0
 *@since 1.8
 */


/**
*Assessment:lab5
*Student Name: Christopher Decarie-Dawson
* Due:7/25/2021 	Done:7/24/2021
*prof: James.M
**/

public class College {//Start the College Database !
	
	/** The college name.
	 * 
	 */
	protected String collegeName;// College name protected as a string.
	
	/** The students ArrayList for holding the number of students and their details.
	 * 
	 */
	protected ArrayList<Student> students;// ArrayList of students and their details.

	/**
	 * Instantiates a new college and a new ArrayList of students.
	 *
	 * @param collegeName the college name
	 * @param numStudents the num students
	 */
	College(String collegeName, int numStudents){//new college
		this.collegeName = collegeName;// sets college name
		students = new ArrayList<>(numStudents);// sets number of students
		
	}
	
	/**
	 * Read studentsDetails outputs the requested data for the user to input into the ArrayList of the college.
	 */
	public void readStudentsdetails(Scanner input) {//reads the input for number of students and offers menu options
			int choice = 0;// holds menu options
			System.out.print("Enter details of student " + (students.size()+1) +": \n" );//outputs details request
			
			do {// loop the menu till either case 1 or case 2 are selected.
				try {			
					 System.out.print("\n===========================\n");// menu fluff
					 System.out.print("1 - Full time student \n2 - Part Time students\n");// options for student type being input into the database.
					 System.out.print("Enter Student type: ");// request for input
					 choice = input.nextInt();// stores option
					 input.nextLine();//clears scanner
					
					 switch (choice) {//takes input and runs it into a switch to call the right methods for each type 
					 	case 1:
					 		Student f = new FulltimeStudent();
					 		students.add(f); 
					 		f.readInfo(input);
					 		break;
					 	case 2:
					 		Student p = new PartTimeStudent();
					 		students.add(p);
					 		p.readInfo(input);
					 		break;
					 		default :
					 			System.err.println("Input Mismatch exception while reading student type");// input error message

					}
				}catch(InputMismatchException exception) {// catch for error input messaging.
					System.err.println("Input Mismmatch Exception while reading student type");
					input.nextLine();
				}

			} while(choice!= 1 && choice!=2);// closing the loop when either of the cases are selected.
				}	
	
	/**
	 * Prints the students details from the database of the college.
	 */
	public void printStudentsDetails() {//prints student details
		if(students.isEmpty()) {
			System.err.println("###### no students to display ######");// error message for no students in the database of the college.
		} else {
			printTitle();
			for(Student student : students) {// calls on the student instances 
				student.printInfo();// prints
			}
		}
		
	}
	public static void printEqual() {// formating fluff for the output menu.
		for(int i = 0; i <= 99; i++) {
			System.out.print("=");
		}
		System.out.println();
	}
		
	/**
	 * Prints the title of the input college in the form requested.
	 *
	 * @param collegeName the college name
	 */
	public void printTitle() {
		printEqual();// fluff printout
		System.out.printf("\t\t\t\t\t"+collegeName+ "- List  of Students\t\t\t\t\t\n" );// setups menu fluff and places college name in requests place
		printEqual();//fluff printout
		System.out.printf(" Program|  Student#  |"+
		"        Name        |       Email ID       |"+
				" PhoneNumber |  GPA |   Fees   | Credits|\n");// menu item lists and columns
	}
	
	/**
	 * Read text file for information input using scanner.
	 *
	 * @param scanner input used to scan the text file.
	 */
	public void readFile(Scanner input) {
		try {// catch for errors such as no file or wrong input types.
			input = new Scanner(Paths.get("students.txt"));
			
		}catch(FileNotFoundException e) {
			System.err.println("File does exist in the given path!");
					
		}catch(IOException e) {
			System.err.println("Invald input");
		}
		
		while(input.hasNext()) {// reads the first Char of the text file for input on student type , fulltime /parttime and adds them to the ArrayList for the college.
			char start = input.next().charAt(0);
			
			switch(start) {
			case'f':
				Student f = new FulltimeStudent();
					students.add(f);
					f.readFileInfo(input);
					break;
			case'p':
				Student p = new PartTimeStudent();
					students.add(p);
					p.readFileInfo(input);
					break;
			
			}
			
		}
		
	}
	
	
	
	

	}//End
	

