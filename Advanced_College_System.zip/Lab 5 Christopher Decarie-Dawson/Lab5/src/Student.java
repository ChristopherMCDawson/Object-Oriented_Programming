import java.util.ArrayList;// ArrayList import
import java.util.Scanner;// scanner import

/**
 * Student class to hold the general student information such as student Number , program name and gpa. it also prints the output basic format ,
 *  holds an arraylist call. It also reads the .txt file for preset students.
 * 
 *@author Christopher Decarie-Dawson
 *@version 2.0
 *@since 1.8
 */
/**
*Assessment:lab5
*Student Name: Christopher Decarie-Dawson
* Due:7/25/2021 	Done:7/24/2021
*prof: James.M
**/

public class Student extends Person implements Policies {// START, extends the person class by adding student based info and implements the policies on to it
	
	
	/** The  protected student number.
	 * 
	 */
	protected int studentNumber;// student number as int  protected
	
	/** The program the student is taking at said college.
	 * 
	  */
	protected String programName;// program name at the college
	
	/** The gpa calculated for ease of quick refencing.
	 * 
	  */
	protected double gpa;// gpa enter for the student
	
	/**
	 * Read info reads the scanner inputs about the requested student variables such as name , student number , email, etc.
	 */
	@Override
	 public void readInfo(Scanner input) {// overrides readInfo to add Student variables
		
		System.out.print("Enter program name: ");//request for program name at the college
		programName = input.next();// sets input of college program name.
		System.out.print("Enter student number: ");// requests for student number attacted to said student.
		studentNumber = input.nextInt();// sets student number in college database.
		System.out.print("Enter first name: ");//requests first name of the student.
		firstName = input.next();//sets first name of the student into the database.
		System.out.print("Enter last name: ");//requests last name of the student.
		lastName = input.next();// sets last name of the student for college database.
		System.out.print("Enter email ID: ");// requests Email ID from student to be entered into Database.
		emailID = input.next();//sets Email ID of the student into the college database.
		System.out.print("Enter phone number: ");//requests phone number of the student for the college database.
		input.nextLine();//adds space
		phoneNumber = input.nextLong();// sets phone number of student into the database.
	
		readMarks(input);// calls on readMarks method to engage
	}

	/**
	 * Read marks takes in the marks of the course and adds them to an ArrayList of doubles for said student the Arraylist  changes to fit the need of the amount of courses taken..
	 */
	private void readMarks(Scanner input) {// reads marks info based on course number input from the ArrayList.
		int courses;		// number of courses holder for the student.
		System.out.print("Enter number of courses: ");//request number of courses that the student is taking.
		courses = input.nextInt();//takes input into the ArrayList to feed into the Array size.
		ArrayList<Double> marks = new ArrayList<>(courses);//creates Arraylist to hold number of courses.
		for(int i = 0; i < courses; i++) {
			System.out.print("Enter mark "+(i+1)+": ");// request input of mark and increasing by one depending on the size of the ArrayList.
			marks.add(input.nextDouble());// Adding the mark to the ArrayList as a double.
			
		}
						
		calculateGPA(marks);// forwarding marks to calculateGPA
	}
	
	
	/**
	 * Calculate GPA.
	 *
	 * @param  public Call to  the ArrayList dobuel array to add up the sum and find the average for finding the GPA, comparing it the Policies set.
	 */
	@Override
	public void calculateGPA(ArrayList<Double> array) {// the double ArrayList is used to store and then calculate the gpa of the student.
		
		double sum = 0;// local sum for calculations ,set to 0.
		
		double average =0;// local average for calculations ,set to 0.
	
		
		for(double v : array){// Call the array to calculate the Gpa.
			sum += v;// adds all the inputs on the double array to create a sum
			average = sum/array.size();// takes the sum and divides it but the number of objects in the array
		}
		gpa = (average * maxGPA) / maxMarks;// calculates the gpa
	}
	
	/**
	 * Prints the info into the requested formating for System output.
	 */
	@Override
	void printInfo() {// overrides the printInfo from Person and adds formatting for programName ,studentNumber ,FirstName and lastName ,email , phone , gpa
		System.out.printf("     %3s|    %8d|%20s|  %20s|  %11d|  %4.2f|",//formating style requested for output.
				programName,
				studentNumber,
				firstName+" "+lastName,
				emailID,phoneNumber,gpa);
		
		
	}
	
	/**
	 * Read file info from the student .txt file in the project source folder , pulling vaild information.
	 *
	 * @param uses Scanner to take input from the .txt file.
	 */
	@Override
	public void readFileInfo(Scanner input){// adds the information when requested from options in menu.
		
		studentNumber = input.nextInt();// sets student number in college database.
		firstName = input.next();//sets first name of the student into the database.
		lastName = input.next();// sets last name of the student for college database.
		emailID = input.next();//sets Email ID of the student into the college database.
		phoneNumber = input.nextLong();// sets phone number of student into the database.
		programName = input.next();// sets input  of college program name.
		gpa = input.nextDouble();// sets  Gpa from .txt file into the college database.
	}
	
}//END
