import java.util.Scanner;// Scanner import
/**
 * extends Student for FulltimeStudents to override base info and print altered info
 * 
 *@author Christopher Decarie-Dawson
 *@version 2.0
 *@since 1.8
 */

/**
*Assessment:lab5
*Student Name: Christopher Decarie-Dawson
* Due:7/25/2021 	Done:7/24/2021
*prof: James.M
**/

public class FulltimeStudent extends Student {//Start extends the student class and adds full time student info

	/** The tuition fees.
	 * 
	 */
	protected double tuitionFees;// tuition fees protected as a double.
	
	/**
	 * Overrides the read info to add in the fulltime student varibles to the print out menu.
	 */
	@Override
	public void readInfo(Scanner input) {// read info override to enter tuition fees for full time students
		super.readInfo(input);//super calling to readInfo from student
		System.out.print("Enter tuition fees: ");//requesting tuition fees
		tuitionFees = input.nextDouble();// inputing double as tuitionFees
		
	}
	
	/**
	 * Overrides the print info to add the variables added for full time students and their formatting.
	 */
	@Override
	 public void printInfo() {// printInfo override to output altered menu for tuition fees
		super.printInfo();// calling printInfo from student
		System.out.printf("%,10.2f|        |\n",tuitionFees);// printing format for tuitionFees
	}
	
	/**
	 * reads and overirdes the  tuitionfees from the text file using a scanner.
	 *
	 * @param input the input
	 */
	@Override
	public void readFileInfo(Scanner input){
		super.readFileInfo(input);
		tuitionFees = input.nextDouble();// inputing double as tuitionFees
	}
	
	
	
}//END
