import java.util.Scanner;//scanner import
/**
 * Extends from student for part-time students.Overrides the readinfo ,printinfo and readfileinfo to add corrections to the ArrayLists holdings said info.
 *
 * @author Christopher Decarie-Dawson
 * @version 2.0
 * @since 1.8
 */

/**
*Assessment:lab5
*Student Name: Christopher Decarie-Dawson
* Due:7/25/2021 	Done:7/24/2021
*prof: James.M
**/

public class PartTimeStudent extends Student {//Start , Extends the student class adding part time student info

	/** The total number of courses taken by the student.
	 *  
	 */
	protected double courseTotal;// course total protected as a double.
	
	/** The credits earned by the student from their courses taken.
	 * 
	 */
	protected double credits;//credits protected as a double.
	
	
	/**
	 * Read info from the scanner input taken from the user and overrides to add in the total course fees and credit hours.
	 * 
	 * @param Scanner input to in-take total course fees and credit hours earned.
	 */
	@Override
	public void readInfo(Scanner input) {// overrides the readInfo to add , total course fee and credit hours.
		super.readInfo(input);//super to pull from readInfo from student.
		System.out.print("Enter total course fees: ");//requests total course fees.
		courseTotal = input.nextDouble();// takes double from user input as course total.
		System.out.print("Enter credit hours: ");//requests credit hours earned by student.
		credits = input.nextDouble();//takes double from user input as earned credits.
		
	}
	/**
	 *  overrides the Prints the info to add courseTotal and credits for part-time students and their formating.
	 */
	@Override
	 public void printInfo() {// overrides the printInfo to add coureTotal and credits for partimeStudents
		super.printInfo();// super pull from printInfo from student
		System.out.printf("%,10.2f|     %3.1f|\n",courseTotal,credits);// print formating for couresTotal and Credits for end output
	}

	/**
	 * Read file info using the scanner and takes the courseTotal and credits from the .txt file in the system.
	 *
	 * @param Scanner input to in-take total course fees and credit hours from text file.
	 */
	@Override
	public void readFileInfo(Scanner input){
		super.readFileInfo(input);// super call to readFileInfo for needed student information.
		courseTotal = input.nextDouble();// takes double from text file.
		credits = input.nextDouble();//takes double from text file.
		
		
	}

	
	
	
}//END
