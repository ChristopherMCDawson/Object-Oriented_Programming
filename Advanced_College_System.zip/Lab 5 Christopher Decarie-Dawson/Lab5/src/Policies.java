import java.util.ArrayList;

/**
 * Policies interface to hold the 2 variables and the GPA Arraylist array.
 * 
 *@author Christopher Decarie-Dawson
 *@version 2.0
 *@since 1.8
 */
/**
*Assessment:lab5
*Student Name: Christopher Decarie-Dawson
* Due:7/25/2021 	Done:7/24/2021
*prof: James.M
**/

public interface Policies {//Start ,interface for Policies used as a refence point for the database.

	/** The max marks available to students.
	 * 
	  */
	double maxMarks = 100;// Set max mark as a double at a max of 100.
	
	/** The max GPA available to students.
	 * 
	  */
	double maxGPA = 4.0;// Set max GPA as a double at a max of 4.0
	
	/**
	 * Calculate GPA using data entered into the ArrayList<Doublle> array.
	 *
	 * @param ArrayList to hold doubles in a array
	 */
	 public void calculateGPA(ArrayList<Double> array);// double ArrayList open to accept input
}//End
