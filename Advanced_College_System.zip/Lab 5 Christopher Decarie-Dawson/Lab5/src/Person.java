import java.util.Scanner;

/**
 * An abstract class to hold variables for a person  and also to take info from files added to the program and to print those variables when called upon.
 *
 * @author Christopher Decarie-Dawson
 * @version 2.0
 * @since 1.8
 */
/**
*Assessment:lab5
*Student Name: Christopher Decarie-Dawson
* Due:7/25/2021 	Done:7/24/2021
*prof: James.M
**/

public abstract class Person {//Start a Public abstract person class.

	
	 /** The first name string set as protected.
	  * 
	   */
 	protected String firstName;// first name Protected.
	
	 /** The last name string set as protected.
	  * 
	    */
 	protected String lastName;// last name protected.
	
	 /** The email ID string set as protected.
	  * 
	    */
 	protected String emailID;// email protected.
	
	 /** The phone number set a long and protected.
	  * 
	    */
 	protected long phoneNumber;//phone number protected.
	 
	 /**
 	 * Read info input by user about students.
 	 *
 	 * @param input from the Scanner about inputs and extensions.
 	 */
 	abstract void readInfo(Scanner input);// reads info from inputs and extensions
	 
 	/**
 	 * Prints the info that was entered into the database of the college.
 	 * 
 	 */
 	abstract void printInfo();// Prints info that was inputed from readInfo and their extensions
 	 	 	/**
	  * Reads file info and intergrates it into the program.
	  *
	  * @param input from the scanner that reads the info on the student.txt file.
	  */
	 abstract void readFileInfo(Scanner input);// reads the students.txt file and brings it into play.
 	
 	
 	
}//END
