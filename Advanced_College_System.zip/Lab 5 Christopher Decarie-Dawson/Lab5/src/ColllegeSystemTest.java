import java.util.InputMismatchException;// error for mismmatch
import java.util.Scanner;//scanner import
/**
 * This is the Driver class to kick start the program. by asking for the college name
 * and number of students then bring up the main menu, also trys and catchs errors done by user input.
 * 
 *@author Christopher Decarie-Dawson
 *@version 2.0
 *@since 1.8
 *@see College
 *@see Person
 *@see Student
 *@see Policies
 *@see FulltimeStudent
 *@see ParTimeStudent
 *
 *
 */

/**
*Assessment:lab5
*Student Name: Christopher Decarie-Dawson
* Due:7/25/2021 	Done:7/24/2021
*prof: James.M
**/



public class ColllegeSystemTest {//Start starts the program!

	/**
 * The main method which powers the whole programs into life!.
 *
 * @param args the arguments
 */
	public static void main(String[] args) {// main method		
		Scanner input  = new Scanner(System.in);// input scanner object for the system to take user input.
		
		
		int n = 0;// local variable for the menu system.
		int choice = 0;// holds the menu option choice.
		boolean work = true;// used for the loop close.
		
		System.out.print("Enter name of College: ");// output asking for College name to be entered.
		String collegeName = input.nextLine();// inputing college name into the system.
		
		
		do {//do loop for setting the number of students with error catchs.
			try {
				System.out.print("Enter Number of students: ");// output asking for Number of students in college.
				 n = input.nextInt();//input set as n
				 if (n <= 0) {
					 throw new IllegalArgumentException("Number of students should be positive..args please try again!");// Tells the user that there can not be negative amount of students.
				 }
				 work = false;// loops till proper input is entered.
			}catch(InputMismatchException e) {
				System.err.println("Input Mismatch Exception while reading nummber of students... please try again!");//error message output.
				input.nextLine();
			}catch(IllegalArgumentException e) {
				System.err.println(e.getMessage());
				input.nextLine();
			}
		}while(work);//closes the loop for send menu.
		
		
		College c1 = new College(collegeName, n);//creating a instance of College
		
		do {// do while loop to prompte user input for  printed menu.
			try {
				System.out.print("\nAvailable options\n"+
						"1. Read Student Info From Keyboard\n"+
						"2. Read Student Info From File\n"+
						"3. Print Details Of All Students\n"+
						"4. Exit\n");
				System.out.print("Choose an option: ");
				choice = input.nextInt();
				
				switch(choice) {// switch cases for each option with error messages for errors in inout.
				case 1:
					c1.readStudentsdetails(input);// calls on the scanner to read student details from the user.
					break;
				case 2:
					c1.readFile(input);
					System.out.println("File read! list is ready");// reads the text file and tells the user the data has been added.
					break;
				case 3:
					c1.printStudentsDetails();// displays all the data in the database of the college from the ArrayList , about the students and their courses.
					break;
				case 4:
					System.out.println("Goodbye.... have a nice day");// Goodbye message for closing the program.
					break;
				default:
					System.err.println("Invalid entry...selection options 1-4... please try again!");// Error message for inproper input.
								}				
				
			}catch(InputMismatchException e) {
					System.err.println("Invalid entry...selection options 1-4... please try again!");// mismatch catch for input errors.
					input.nextLine();
			}
		}while(choice != 4);// loops the program menu till 4 is input.
				
		input.close();// Closes Scanner input
		
	}

}//END
