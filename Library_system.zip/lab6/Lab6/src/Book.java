import java.util.Scanner;

/**
 * Book class holds all the book details , from name to author to Isbn , the amount of said books and their prices.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class Book {
	
	private long isbn;// book look up code
	
	private String bookName;// bookname holder
	
	private String authorName;// author of the book
	
	private double price;// price of book when bought
	
	int quantity;// amount of books in stock
	
	private boolean borrowed;// weither the book is borrowed or not


	public String getBookName() {// getting for book name
		return bookName;
	}

	public int getQuantity() {// getting for the amount of books on hand
		return quantity;
	}

	public void setBorrowed(boolean borrowed) {// setter for borrowing the book
		this.borrowed = borrowed;
	}
	public void readInfo(Scanner input) {// menu for taking in a books details , adding new books to the database.
		System.out.print("Enter book ISBN: ");
		isbn = input.nextLong();
		System.out.print("enter Book name: ");
		input.nextLine();
		bookName = input.nextLine();
		System.out.print("Enter name of author: ");
		authorName = input.nextLine();
		System.out.print("Enter book price: ");
		price = input.nextDouble();
		System.out.print("Enter book quantity: ");
		quantity = input.nextInt();
		
	}
	public void readFileInfo(Scanner input) {// Reading books already listed in the database in text file form.
		isbn = input.nextLong();
		bookName = input.next().replace('+',' ');
		authorName = input.next().replace('+',' ');
		price = input.nextDouble();
		quantity = input.nextInt();
	}
	
	/**
	 * Prints the info.
	 */
	public void printInfo() {// formatting for book info printing.
		System.out.printf("%13d| %38s|%38s| %5.2f |   %2d   |",
				isbn,
				bookName,
				authorName,
				price,
				quantity);
		
	}

}
