import java.util.ArrayList;
import java.util.Scanner;
/**
 * Driver class to run the program for the libaray database.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class Staff extends User{// Start
	
	protected long ID;// Id number
	
	protected int floor;// floor working on
	
	protected String section;// area of floor working at
	
	/** The staff list. */
	protected ArrayList<Staff> staffList = new ArrayList<>();
	 
	 
	 
	 @Override
	 public int staff(Scanner input) {
		 int choice;
		 System.out.println("Please Select a Option to begin");
		 System.out.println("1: Enter Employee details\n" + 
				 "2: Add a book\n" + 
				 "3: Create database from file\n" + 
				 "4: Find a book\n" + 
				 "5: remove a book\n" + 
				 "6: Display database\n" + 
				 "7: Display employee file\n" + 
				 "8: Exit");
		 System.out.print("Enter option: ");
		 choice = input.nextInt();
		 return choice;		 
	 }
	 
	 
	@Override
	public void readInfo(Scanner input) {
		super.readInfo(input);
		System.out.print("Enter Staff ID number: ");
		ID = input.nextLong();
		System.out.print("Enter floor number: ");
		floor = input.nextInt();
		System.out.print("Enter section number: ");
		section = input.next();
		
	}
	@Override
	 public void printInfo() {// printInfo override to output altered menu for tuition fees
		super.printInfo();// calling printInfo from user
		System.out.printf("  %6d  | %40s | %30s | %11d | %10 | %2d | %3d |\n",ID,
				firstName + " " + lastName,
				email,
				phoneNumber,
				floor,
				section);// printing format 
	}
	

}//ENd
