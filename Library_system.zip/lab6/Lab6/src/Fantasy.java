import java.util.Scanner;

/**
 * fan subclass to add in to deal with fan books.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class Fantasy extends Fiction {
	
	/** The subcategory non fiction. */
	String subcategoryNonFiction;
	
	
	/**
	 * Read info.
	 *
	 * @param input the input
	 */
	@Override
	public void readInfo(Scanner input) {
		super.readInfo(input);
		System.out.print("Enter sub-category: ");
		subcategoryNonFiction = input.next();
	}
	
	/**
	 * Prints the info.
	 */
	@Override
	public void printInfo() {
		super.printInfo();
		System.out.printf(" %10s |\n",subcategoryNonFiction);
	}
	
	/**
	 * Read file info.
	 *
	 * @param input the input
	 */
	@Override
	public void readFileInfo(Scanner input) {
		super.readFileInfo(input);
		subcategoryNonFiction = input.next();
		
	}

}
