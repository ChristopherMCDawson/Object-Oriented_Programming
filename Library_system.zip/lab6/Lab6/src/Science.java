import java.util.Scanner;

/**
 * Science subclass to add in to deal with Science books.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */

/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class Science extends NonFiction {//start

	/** The subcategory non fiction. */
String subcategoryNonFiction;
	
	
	/**
	 * Read info from arrrylists.
	 *
	 * @param takes user input
	 */
	@Override
	public void readInfo(Scanner input) {// readinfo and overrides with user input
		super.readInfo(input);
		System.out.print("Enter sub-category: ");
		subcategoryNonFiction = input.next();
	}
	
	/**
	 * Prints the info from arraylists.
	 */
	@Override
	public void printInfo() {// Overrides the printinfo formatting
		super.printInfo();
		System.out.printf(" %10s |\n",subcategoryNonFiction);
	}
	
	/**
	 * Read file info from book.txt.
	 *
	 * @param takes the user input
	 */
	@Override
	public void readFileInfo(Scanner input) {// overrides the readfile to take in non fiction
		super.readFileInfo(input);
		subcategoryNonFiction = input.next();
		
	}
}//end
