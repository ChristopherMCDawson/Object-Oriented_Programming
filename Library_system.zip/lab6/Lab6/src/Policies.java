
/**
 *Intereface for the database to apply policies.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */

/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public interface Policies {
	
	
	int FINE_LIMIT = 14;
	int FINE = 1 ;
	
	void checkData();

}
