import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * Members system for the databse
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */



/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/
public class Member extends User implements Policies {

	protected long memberID;

	protected ArrayList<Book> memberBooks = new ArrayList<>();

	protected LocalDate dateBorrow;

	protected LocalDate dateReturn;
	
	
	@Override
	public int member(Scanner input) {
		int choice;
		System.out.println("Member's menu options");
		System.out.println("1: Borrow a book\n" + 
				"2: Return a book\n" + 
				"3: Display borrowed books");
		System.out.print("Choose your option");
		choice = input.nextInt();
		return choice ;
	}
	private int bookArray(Scanner input){
		
			int limit = 0;
			
			do {
				try {
					if(memberBooks.size()>=5) {
						System.out.println("Max number of books taken");
						break;
					}
					System.out.print("how many books would you like to take out");
					limit =input.nextInt();
					
					if(limit > 5) {
						System.out.println("Can not borrow more then Five(5) books");
					} else if (limit <0) {
						System.out.println("A book must been borrowed, must be greater then zero books");
					} else if (limit ==0) {
						System.out.println("A book must been borrowed, must be greater then zero books");
					}
					
				}catch (InputMismatchException e) {
					System.err.println("Wrong input , try again");
					input.nextLine();
				}catch(IllegalArgumentException e) {
					System.err.println("Incorrect input");
				}
			}while (limit >5||limit <=0);
			return limit;
	}
	public void borrowBook(Scanner input, ArrayList<Book> bookList) {
		if (bookList.isEmpty()) {
			System.out.println("No books avaible!!!");
		}else {
			int arraySize = bookArray(input);
			input.nextLine();
			for(int i =0;i<arraySize;i++) {
				System.out.print("Enter name of book" + (i+1) + " : ");
				String bName = input.nextLine();
				
				int index = 0;
				for(; index<bookList.size(); index++) {
					if(bookList.get(index).getBookName().equalsIgnoreCase(bName)) {
						if(memberBooks.contains(index)) {
							System.out.println("Book is Already borrroed");
									
						}else {
							Book book = bookList.get(index);
							book.setBorrowed(true);
							System.out.println("Book has been borrowed on" + dateBorrow + "!");
							memberBooks.add(book);						
							book.quantity--;
							dateBorrow = LocalDate.now();
							break;
						}
						
					}
					}
					if(index>=bookList.size()) {
						System.out.println("This book doesn't exist");
					}
				}
			}
		}
	
	public void returnBook(Scanner input, ArrayList<Book>bookList) {
		if (memberBooks.isEmpty()) {
			System.out.println("No books to return");
		}else {
			System.out.print("Enter the name of the book being reutned");
			String bName = input.nextLine();
			int i = 0;
			for(;i<bookList.size();i++) {
				if(bookList.get(i).getBookName().equalsIgnoreCase(bName)) {
					checkData();
					Book book =bookList.get(i);
					book.setBorrowed(false);
					memberBooks.remove(book);					
					book.quantity++;
					System.out.println("Book has been returned on " + dateReturn);
					break;
				}
				if(i >= bookList.size()) {
					System.out.println("Book is not in System");
				}
			}
		}
	}
	@Override
	public void checkData() {
		LocalDate deadLine = dateBorrow.plusDays(13);
		dateReturn = LocalDate.now();
		
		int difference = dateReturn.getDayOfMonth()- deadLine.getDayOfMonth();
		int time = difference + FINE_LIMIT;
		
		if(time > FINE_LIMIT) {
			int fine =FINE * difference;
			System.out.println(" Total oweing balance is "+fine);
		} else {
			System.out.println("No balance is owed");
		}
	}
	public void displayBook(ArrayList<Book>bookList) {
		if (bookList.isEmpty()) {
			System.out.println("no books to display");
			
		}else {
			Library.printTitle();
				for(Book book : bookList) {
					book.printInfo();
			}
		 }
	}
		
}
	


