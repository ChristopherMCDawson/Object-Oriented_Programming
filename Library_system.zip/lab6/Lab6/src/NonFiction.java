import java.util.Scanner;

// TODO: Auto-generated Javadoc
/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class NonFiction extends Book {
	
	/** The category NF. */
	String categoryNF;
	
	
	/**
	 * Read info.
	 *
	 * @param input the input
	 */
	@Override
	public void readInfo(Scanner input) {
		super.readInfo(input);
		System.out.print("Enter category: ");
		categoryNF = input.nextLine();
	}
	
	/**
	 * Read file info.
	 *
	 * @param input the input
	 */
	@Override
	public void readFileInfo(Scanner input) {
		super.readFileInfo(input);
		categoryNF = input.nextLine();
	}
	
	/**
	 * Prints the info.
	 */
	@Override
	public void printInfo() {
		super.printInfo();
		System.out.printf("%11s|",categoryNF);
	}

}
