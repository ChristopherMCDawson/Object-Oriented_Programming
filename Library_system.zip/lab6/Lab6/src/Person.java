import java.util.Scanner;

// TODO: Auto-generated Javadoc
/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public  abstract class Person {

	
	/** The first name. */
	protected String firstName;
	
	/** The last name. */
	protected String lastName;
	
	/** The email. */
	protected String email;
	
	/** The phone number. */
	protected long phoneNumber;
	
	/**
	 * Read info.
	 *
	 * @param input the input
	 */
	abstract void readInfo(Scanner input);

	/**
	 * Prints the info.
	 */
	abstract void printInfo();
	
	
	
	
	
}
