import java.util.Scanner;

/**
*Assessment:
*Student Name: Christopher Decarie-Dawson
* Due: 	Done:
*prof: James.M
**/

public class Fiction extends Book {
	
	String categoryF;
	
	@Override
	public void readInfo(Scanner input) {
		super.readInfo(input);
		System.out.print("Enter category: ");
		categoryF = input.nextLine();
	}
	
	@Override
	public void readFileInfo(Scanner input) {
		super.readFileInfo(input);
		categoryF = input.nextLine();
	}
	@Override
	public void printInfo() {
		super.printInfo();
		System.out.printf("%11s|",categoryF);
	}
	

}
