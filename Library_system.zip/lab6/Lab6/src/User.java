
import java.util.Scanner;
// TODO: Auto-generated Javadoc

/**
 * User creates user a new user object and takes in it's details for the database.
 *
 * @author Christopher Decarie-Dawson
 * @version 1.0
 * @since 1.8
 */

/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class User extends Person {//Start

	
	/** The person. */
Person person;
	
	/**
	 * Instantiates a new user.
	 */
	User(){	// no agrs constantor		
	}	
	
	/**
	 * Instantiates a new user.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param email the email
	 * @param phoneNumber the phone number
	 */
	User(String firstName,String lastName,String email,long phoneNumber){// for stating user details
		person = new User(firstName, lastName, email, phoneNumber);	// a instance of User.	
	}	
	
	/**
	 * Read info.
	 *
	 * @param input the input
	 */
	@Override
	void readInfo(Scanner input) {
		System.out.print("Enter first name: ");//requests first name of the person.
		firstName = input.next();//sets first name of the person into the database.
		System.out.print("Enter last name: ");//requests last name of the person.
		lastName = input.next();// sets last name of the person for the database.
		System.out.print("Enter email ID: ");// requests Email ID from person to be entered into Database.
		email = input.next();//sets Email ID of the person into the database.
		System.out.print("Enter phone number: ");//requests phone number of the person for the database.
		input.nextLine();//adds space
		phoneNumber = input.nextLong();// sets phone number of person into the database.
	}

	/**
	 * Prints the info.
	 */
	@Override
	void printInfo() {
		System.out.printf("|%40s |  %30s |  %11d |\n",//formating style for output.
		firstName+" "+lastName,email,phoneNumber);
		
	}

	/**
	 * Staff.
	 *
	 * @param input the input
	 * @return the int
	 */
	public int staff(Scanner input) {
		return 0;
	}
	
	/**
	 * Member.
	 *
	 * @param input the input
	 * @return the int
	 */
	public int member(Scanner input) {
		return 0;
	}
	
	
	
	
}//end
	
	
	


