import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Library class to hold all the menu options for the users and to out weither books are in the database or not and to add a book if wanted.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */

/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class Library {
	
	
	protected static String lName;
	protected ArrayList<Staff>users=new ArrayList<>();
	protected ArrayList<Book>database =new ArrayList<>();
	private String first;
	
	
	Library(String name){//Start
		lName = name;
	}
	public void addBook(Scanner input) {//adds books to database and expands the size of the system.
		 int option = 0;
		 System.out.print("Enter details of book " + database.size()+1);
		 
		 
		 do {
			 try {
				 System.out.println("Select category\n"
				 		+ "1: Fiction\n" 
					    + "2: non-fiction");
				 option = input.nextInt();
				 
				 switch(option) {// switch case to run the menu above , with catching added for errors.
				 case 1:
					 int select = 0;
					 do {// menu system for picking fiction categories
						 try {
							 System.out.println("Select sub-category\n" + 
									 "1: Cosmic\n 2: Fantasy");
							 select = input.nextInt();
							 switch (select) {
							  case 1:
								 Book c = new Comic();
								 database.add(c);
								 c.readInfo(input);
								 break;
							  case 2:	
								  Book f = new Fantasy();
								  database.add(f);
								  f.readInfo(input);
								  break;
								  default:
									  System.out.println("Incorrect input");
						 }
												
					
						 }catch(InputMismatchException e) {// catch for input errors
							 System.err.println("Wrong input , try again");
							 input.nextLine();
						 }
					 }while(select != 1 && select != 2);// loops till 1 or 2 are selected
					 break;
				 case 2:
					 int choose = 0;
					 do {// another menu system for picking non fiction categories
						 try {
							 System.out.println("Select sub-category\n" + 
									 "1: Biography\n 2: History\n 3: Science");
							 choose = input.nextInt();
							 switch (choose) {
							  case 1:
								 Book b = new Biography();
								 database.add(b);
								 b.readInfo(input);
								 break;
							  case 2:	
								  Book h = new History();
								  database.add(h);
								  h.readInfo(input);
								  break;
							  case 3:
								  Book s = new Science();
									 database.add(s);
									 s.readInfo(input);
									 break;
								  default:
									  System.out.println("Incorrect input");
						 }
												
					
						 }catch(InputMismatchException e) {// catchs for input error
							 System.err.println("Wrong input , try again");
							 input.nextLine();
						 }
					 }while(choose != 1&& choose != 2 && choose !=3);// loops till one of the cases is picked
					 break;
					 default:
						 System.out.println("incorrect category");
				 }
			 }catch(InputMismatchException e) {
				 System.err.println("Wrong input , try again");// input error catch
				 input.nextLine(); 
			 }
		 }while(option !=1 && option !=2);// loops till 1 or 2 are entered
				 
	}
	public void removeBook(Scanner input, ArrayList<Book>bookList) {// removing books from the database
		if(bookList.isEmpty()) {
			System.out.println("No books to remove");// no books error
		}else {
			System.out.print("enter name of book: ");
			input.nextLine();
			String bName = input.nextLine();
			int i =0;
			for(;i<bookList.size();i++) {
				if(bookList.get(i).getBookName().equalsIgnoreCase(bName)) {
					break;
				}
			}
			if(i >= bookList.size()) {
				System.out.println("this book does not exist in the Library");// error for non system book
				return;
			}
			int index = i;
			for(int j =index;j<bookList.size()-1;j++) {
				Book nextBook = bookList.get(j+1);
				bookList.add(j,nextBook);
			}
			bookList.remove(i);
			System.out.println("the book has been removed Successfully");// removing book message
		}
		
	}
	public void findBook (Scanner input, ArrayList<Book>bookList) {// book finder 
		if(bookList.isEmpty()) {
			System.err.println("No books Avabilable");// no books error
		
		}else {
			System.out.print("enter the name of the book you are searching for.");// checker for books item
			input.nextLine();
			String bName = input.nextLine();
			int i =0;
			for (;i<bookList.size();i++) {
				if(bookList.get(i).getBookName().equalsIgnoreCase(bName)) {
					System.out.println(bookList.get(i).getBookName() 
						+" is in the Library");
					break;
				}
			}
			if(i>= bookList.size()) {
				System.out.println("This book does not exist in the library");// non book in the database
		}
	}
}
	public void	printBookDetails(ArrayList<Book>bookList) {// prints off the details of the books requested
		if(bookList.isEmpty()) {
			System.err.println(" No books to display");
		} else {
			printTitle();
			for(Book book : bookList) {
				book.printInfo();
			}
		}
	}
	public void printUserDetails(ArrayList<Staff>staffList) {// prints the details of the user requested
		if(staffList.isEmpty()) {
			System.err.println("No users to Display");
		}else {
			printUserTitle();
			for(Staff staff : staffList) {
				staff.printInfo();
			}
			
		}
	}
	public static void printDollar() {// menu formatting
		for(int i= 0; i <= 120;i++) {
			System.out.print("$");
		}
		System.out.println();
	}
		public static void printTitle() {// menu title page formatting
		printDollar();
		System.out.print("\t\t\t\t\t\t\t\t" + lName + " - List of Books\t\t\t\t\t\n");
		printDollar();
		System.out.println("    ISBN     |           Book Name           |" +
				"         Author Name         | Price |" + 
				" Quantity | Category  |sub-category|\n");		
	}
	public static void printUserTitle() {// user title formatting
		printDollar();
		System.out.print("\t\t\t\t\t\t\t\t" + lName + " - List of Users\t\t\t\t\t\n");
		printDollar();
		System.out.println(" Staff Id |                User Name                 |" + 
				"             Email Id          |" +
				"PhoneNumber |  Section |\n" );
	}
	
	/**
	 * Read file.
	 *
	 * @param input the input
	 */
	public void readFile(Scanner input) {// reads fille infor for database
		try {
			input = new Scanner(Paths.get("Book.txt"));
		}catch(FileNotFoundException e) {
			System.err.println("file does not exist in the given path!");
		}catch(IOException e) {
			System.err.println("Incorrect Data entry");
		}
		while(input.hasNext()) {
			try {
					char letter = input.next().charAt(0);
					
					switch(letter) {
					case 'c':
						Book c = new Comic();
						database.add(c);
						c.readFileInfo(input);
						break;
					case 'f':
						Book f = new Fantasy();
						database.add(f);
						f.readFileInfo(input);
						break;	
					case 'h':
						Book h = new History();
						database.add(h);
						h.readFileInfo(input);
						break;
					case 'b':
						Book b = new Biography();
						database.add(b);
						b.readFileInfo(input);
						break;
					case 's':
						Book s = new Science();
						database.add(s);
						s.readFileInfo(input);
						break;
					}
			}catch(NullPointerException e) {
				System.err.println("incorrect file");
			}
		}
	}
	
	
	
}//End
