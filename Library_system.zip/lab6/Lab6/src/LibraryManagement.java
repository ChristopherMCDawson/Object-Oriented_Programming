import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * Main driver class for the system.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */

/**
*Assessment:lab6
*Student Name: Christopher Decarie-Dawson
* Due:8/8/2021 	Done:8/8/2021
*prof: James.M
**/

public class LibraryManagement {

	/**
	 * The main method.
	 *
	 * @param drives the main method
	 */
	public static void main(String[] args) {
		
	Scanner input = new Scanner(System.in);	//scanner
	int choice =0;
	System.out.print("Enter name of library: ");
	String lName = input.nextLine();
	Library lib = new Library(lName);
	Staff s = new Staff();
	Member m = new Member();
	int option = 0;
	int select =0;
	
	do {// menu for choicing input type
		try {
			System.out.println("Choose user");
			System.out.println("1: Staff\n2: Member\n3 Exit");
			System.out.print("Choose an option: ");
			choice = input.nextInt();
			if (choice <= 0) {
				throw new IllegalArgumentException("please enter a Number above 0 ");
			}
			switch(choice) {
			case 1:
				do {
					try {
						option = s.staff(input);
						switch(option) {
						case 1:
							s = new Staff();
							s.staffList.add(s);
							s.readInfo(input);
							break;
						case 2:
							lib.addBook(input);
							break;
						case 3:
							lib.readFile(input);
							if(!lib.database.isEmpty()) {
								System.out.println("File read! list is ready");
							}
							break;
						case 4:
							lib.removeBook(input, lib.database);
							break;
						case 5:
							lib.findBook(input, lib.database);
							break;
						case 6:
							lib.printBookDetails(lib.database);
							break;
						case 7:
							lib.printUserDetails(s.staffList);
							break;
						case 8:
							System.out.println(" thank you using the system Goodbye");
							break;
						default:
							System.err.println("wrong input try again");
							
						}
						
					}catch(InputMismatchException e) {
						System.err.println("wrong entry try agin");
						input.nextLine();
					}catch(IllegalArgumentException e) {
						System.err.println(e.getMessage());
						input.nextLine();
					}
				}while (option != 8);
				break;
			case 2:
				do {
					try {
						select = m.member(input);
						switch(select) {
						case 1:
							m.borrowBook(input, lib.database);
							break;
						case 2:
							m.returnBook(input, lib.database);
							break;
						case 3:
							m.displayBook(m.memberBooks);
							break;
						case 4:
							System.out.println("thank you stopping at"+ lName +"Goodbye");
							break;
							default:
								System.err.println("wrong input, try again");
						}
					}catch(InputMismatchException e) {
						System.err.println("wrong entry try agin");
						input.nextLine();
				}catch(IllegalArgumentException e) {
					System.err.println(e.getMessage());
					input.nextLine();
			}
			
		}while(choice != 4);
				break;
			case 3:
				System.out.println("have a nice day");
				break;		
			default :
				System.err.println("wrong entry try again");
			
			
	}
	}catch(InputMismatchException e) {
		System.err.println("wrong entry try agin");
		input.nextLine();
		input.close();	
	}catch(IllegalArgumentException e) {
		System.err.println(e.getMessage());
		input.nextLine();
}
	}while(choice != 3);
	input.close();
	}
}

