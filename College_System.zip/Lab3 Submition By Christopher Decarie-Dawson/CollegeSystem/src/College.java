import java.util.Scanner;//scanner import

/**
 * College class to ask for input and setup menu formating for the main and the the last outputs
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */


/**
*Assessment:lab3
*Student Name: Christopher Decarie-Dawson
* Due:6/20/2021 	Done:6/20/2021
*prof: James.M
**/

public class College {//Start
	
	/** The college name.
	 */
	protected String collegeName;// College name
	
	/** The students.
	 * 
	 */
	protected Student[] students;// array of students

	/**
	 * Instantiates a new college.
	 *
	 * @param collegeName the college name
	 * @param numStudents the num students
	 */
	College(String collegeName, int numStudents){//new college
		this.collegeName = collegeName;// sets college name
		students = new Student[numStudents];// sets number of students
		
	}
	
	/**
	 * Read studentsDetails.
	 */
	public void readStudentsdetails() {//reads the input for number of students and offers menu options
		for(int i = 0; i < students.length; i++) {
			int choice;// holds menu options
			Scanner input = new Scanner(System.in);//scanner input
			System.out.print("Enter details of student " + (i+1) +": " );//outputs details request
			System.out.print("\n===========================\n");// menu fluff
			System.out.print("1 - Full time student \n2 - Part Time students\n");// options for student type
			System.out.print("Enter Student type: ");// request for input
			choice = input.nextInt();// stores option
			input.nextLine();//clears scanner
			
		switch (choice) {//takes input and runs it into a switch to call the right methods for each type 
			case 1:
				students[i] = new FulltimeStudent();
				students[i].readInfo();
				break;
			case 2:
				students[i] = new PartTimeStudent();
				students[i].readInfo();
				break;
			default :
				System.out.println("Wrong student type");// input error message
				i--;// resets the menu to repick Student type
			}
		}
	}	
	
	/**
	 * Prints the students details.
	 */
	public void printStudentsDetails() {//prints student details
		for(Student student : students) {// calls on the student instances 
			student.printInfo();// prints
		}
	}
		
	/**
	 * Prints the title.
	 *
	 * @param collegeName the college name
	 */
	public void printTitle(String collegeName) {
		System.out.printf("%s - List  of Students\t\t\t\t\t\n", collegeName);// setups menu fluff and places college name in requests place
		System.out.println("*************************************");// menu fluff
		System.out.printf("  Program| Student#|           Name|       Email|    Phone|  GPA| Fees| Credits|\n");// menu item lists and columns
	}

	}//End
	

