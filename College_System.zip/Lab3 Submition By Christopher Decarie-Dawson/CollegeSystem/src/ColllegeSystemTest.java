import java.util.Scanner;//scanner import
/**
 * This is the Driver class to kick start the program
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 *@see College
 *@see Person
 *@see Student
 *@see Policies
 *@see FulltimeStudent
 *@see ParTimeStudent
 *
 *
 */

/**
*Assessment:lab3
*Student Name: Christopher Decarie-Dawson
* Due:6/20/2021 	Done:6/20/2021
*prof: James.M
**/



public class ColllegeSystemTest {//Start

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {// main method
		
		Scanner input  = new Scanner(System.in);// input scanner object
		System.out.print("Enter name of College: ");// output asking for College name
		String name = input.nextLine();// inputing college name
		
		System.out.print("Enter Number of students: ");// output asking for Number of students
		int n = input.nextInt();//input set as n
		College c1 = new College(name, n);//creating a instance of College
		
		c1.readStudentsdetails();// calling method
		c1.printTitle(name);// calling method
		c1.printStudentsDetails();// calling method
		input.close();// Closes Scanner input
		
	}

}//END
