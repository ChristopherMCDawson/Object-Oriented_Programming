/**
 * Policies interface to hold the 3 variables
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
*Assessment:lab3
*Student Name: Christopher Decarie-Dawson
* Due:6/20/2021 	Done:6/20/2021
*prof: James.M
**/

public interface Policies {//Start ,interface for Policies

	/** The max marks.
	 * 
	  */
	double maxMarks = 100;// Set max mark
	
	/** The max GPA.
	 * 
	  */
	double maxGPA = 4.0;// Set max GPA 
	
	/**
	 * Calculate GPA.
	 *
	 * @param array the array
	 */
	void calculateGPA(double[] array);// double array open to accept input
}//End
