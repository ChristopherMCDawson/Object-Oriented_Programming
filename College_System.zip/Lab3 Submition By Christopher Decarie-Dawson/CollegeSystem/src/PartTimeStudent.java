import java.util.Scanner;//scanner import
/**
 * Extends from student for par-time students.
 *
 * @author Christopher Decarie-Dawson
 * @version 1.0
 * @since 1.8
 */

/**
*Assessment:lab3
*Student Name: Christopher Decarie-Dawson
* Due:6/20/2021 	Done:6/20/2021
*prof: James.M
**/

public class PartTimeStudent extends Student {//Start , Extends the student class adding part time student info

	/** The course total.
	 *  
	 */
	protected double courseTotal;// course total
	
	/** The credits.
	 * 
	 */
	protected double credits;//credits
	
	
	/**
	 * Read info.
	 */
	@Override
	public void readInfo() {// overrides the readInfo to add , total course fee and credit hours
		Scanner input = new Scanner(System.in);//scanner
		super.readInfo();//super to pull from readInfo from student
		System.out.print("Enter total course fees: ");//requests total course fees
		courseTotal = input.nextDouble();// takes double
		System.out.print("Enter credit hours: ");//requests credit hours
		credits = input.nextDouble();//takes double
		
	}
	
	/**
	 * Prints the info.
	 */
	@Override
	void printInfo() {// overrides the printInfo to add coureTotal and credits for partimeStudents
		super.printInfo();// super pull from printInfo from student
		System.out.printf(" %,5.1f|   %3.1f  |\n",courseTotal,credits);// print formating for couresTotal and Credits for end output
	}
	
}//END
