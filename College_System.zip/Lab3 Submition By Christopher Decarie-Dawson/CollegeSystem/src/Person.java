/**
 * An abstract class to hold variables for a person and to print those variables when called upon
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
*Assessment:lab3
*Student Name: Christopher Decarie-Dawson
* Due:6/20/2021 	Done:6/20/2021
*prof: James.M
**/

public abstract class Person {//Start

	
	 /** The first name.
	  * 
	   */
 	protected String firstName;// first name
	
	 /** The last name.
	  * 
	    */
 	protected String lastName;// last name
	
	 /** The email ID.
	  * 
	    */
 	protected String emailID;// email
	
	 /** The phone number.
	  * 
	    */
 	protected long phoneNumber;//phone number
	 
	 /**
 	 * Read info.
 	 */
 	abstract void readInfo();// reads info from inputs and extensions
	 
 	/**
 	 * Prints the info.
 	 */
 	abstract void printInfo();// Prints info that was inputed from readInfo and their extensions
}//END
