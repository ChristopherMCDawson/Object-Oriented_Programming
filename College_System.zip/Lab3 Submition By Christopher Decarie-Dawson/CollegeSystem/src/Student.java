import java.util.Scanner;// scanner import

/**
 * Student class to hold the general student information such as student Number , program name and gpa
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
*Assessment:lab3
*Student Name: Christopher Decarie-Dawson
* Due:6/20/2021 	Done:6/20/2021
*prof: James.M
**/

public class Student extends Person implements Policies {// START, extends the person class by adding student based info and implements the policies on to it
	
	
	/** The student number.
	 * 
	 */
	protected int studentNumber;// student number
	
	/** The program name.
	 * 
	  */
	protected String programName;// program name
	
	/** The gpa.
	 * 
	  */
	protected double gpa;// gpa
	
	/**
	 * Read info.
	 */
	@Override
	 public void readInfo() {// overrides readInfo to add Student variables
		Scanner input = new Scanner(System.in);//scanner for input
		System.out.print("Enter program name: ");//request for program name
		programName = input.next();// sets input
		System.out.print("Enter student number: ");// requests for student number
		studentNumber = input.nextInt();// sets student number
		System.out.print("Enter first name: ");//requests first name
		firstName = input.next();//sets first name
		System.out.print("Enter last name: ");//requests last name
		lastName = input.next();// sets last name
		System.out.print("Enter email ID: ");// requests Email ID
		emailID = input.next();//sets Email ID
		System.out.print("Enter phone number: ");//requests phone number
		input.nextLine();//adds space
		phoneNumber = input.nextLong();// sets phone number
	
		readMarks();// calls on readMarks method to engage
	}

	/**
	 * Read marks.
	 */
	private void readMarks() {// reads marks info based on course number input array
		Scanner input = new Scanner(System.in);//scanner
		int courses;		// number of course holder
		System.out.print("Enter number of courses: ");//request number of courses
		courses = input.nextInt();//takes input
		double[] marks = new double[courses];//creates array to hold number of courses
		for(int i = 0; i < marks.length; i++) {
			System.out.print("Enter mark "+(i+1)+": ");// request input of mark and increasing by one depending on size of array
			marks[i] = input.nextDouble();// setting mark and moving i forward
				
		}
						
		calculateGPA(marks);// forwarding marks to calculateGPA
	}
	
	/**
	 * Calculate GPA.
	 *
	 * @param array the array
	 */
	@Override
	public void calculateGPA(double[] array) {// the double array is used to store and then calculate the gpa of the student
		
		double sum = 0;// local sum for calculations ,set to 0
		
		double average =0;// local average for calculations ,set to 0
	
		
		for(int i =0; i < array.length; i++){
			sum = sum + array[i];// adds all the inputs on the double array to create a sum
			average = sum/array.length;// takes the sum and divides it but the number of objects in the array
		}
		gpa = (average * maxGPA) / maxMarks;// calculates the gpa
	}
	
	/**
	 * Prints the info.
	 */
	@Override
	void printInfo() {// overrides the printInfo from Person and adds formatting for programName ,studentNumber ,FirstName and lastName ,email , phone , gpa
		System.out.printf("%9s|%8d|%15s|%11s|%9d|%5.2f|",//formating
				programName,
				studentNumber,
				firstName+" "+lastName,
				emailID,phoneNumber,gpa);
		
		
	}
	
}//END
