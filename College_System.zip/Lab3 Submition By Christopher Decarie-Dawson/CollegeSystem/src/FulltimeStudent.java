import java.util.Scanner;// Scanner import
/**
 * extends Student for FulltimeStudents to override base info and print altered info
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */

/**
*Assessment:lab3
*Student Name: Christopher Decarie-Dawson
* Due:6/20/2021 	Done:6/20/2021
*prof: James.M
**/

public class FulltimeStudent extends Student {//Start extends the student class and adds full time student info

	/** The tuition fees.
	 * 
	 */
	protected double tuitionFees;// tuition fees
	
	/**
	 * Read info.
	 */
	@Override
	public void readInfo() {// read info override to enter tuition fees for full time students
		Scanner input = new Scanner(System.in);//scanner input
		super.readInfo();//super calling to readInfo from student
		System.out.print("Enter tuition fees: ");//requesting tuition fees
		tuitionFees = input.nextDouble();// inputing double as tuitionFees
		
	}
	
	/**
	 * Prints the info.
	 */
	@Override
	void printInfo() {// printInfo override to output altered menu for tuition fees
		super.printInfo();// calling printInfo from student
		System.out.printf(" %,5.1f|        |\n",tuitionFees);// printing format for tuitionFees
	}
	
	
}//END
