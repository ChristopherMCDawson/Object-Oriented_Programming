
/*
 *Person Stores the private variables of a person's data. requests the data with getters.
 *Asks for first name last name  , email and phone number and returns said variables to their 
 *spots on the arraylist.
 *
 *
 *
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
import java.util.Scanner;//Scanner import

/**
 * Assessment: lab4 Student Name: Christopher Decarie-Dawson Due:7/11/2021
 * Done:7/9/2021 prof: James.M
 **/

public class Person {// START

	/** The first name. */
	private String firstName;// first name taken as a string

	/** The last name. */
	private String lastName;// last name taken as a string

	/** The email. */
	private String email;// Email taken as a string

	/** The phone number. */
	private long phoneNumber;// Phone number taken in asa long

	/**
	 * Gets the full name.
	 *
	 * @return the full name input From User
	 */
	public String getFullName() {// Requests full name
		return firstName + " " + lastName;// set / returns the first and last name as one output
	}

	/**
	 * Gets the email.
	 *
	 * @return the email input From User
	 */
	public String getEmail() {// Requests email
		return email;// Sets / returns email
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phone number input From User
	 */
	public long getPhoneNumber() {//
		return phoneNumber;// sets/ returns phone number
	}

	/**
	 * Read personal details. Requests outputed to user and inputs returned to
	 * variables
	 *
	 * @param in calls the Scanner from bankTest driver class
	 */
	public void readPersonalDetails(Scanner in) {// reads out the requested outputs and takes in inputs from driver
													// class scanner
		System.out.print("Enter first name: ");
		firstName = in.next();
		System.out.print("Enter last name: ");
		lastName = in.next();
		System.out.print("Enter email: ");
		email = in.next();
		System.out.print("Enter phone number: ");
		phoneNumber = in.nextLong();
	}
}// END