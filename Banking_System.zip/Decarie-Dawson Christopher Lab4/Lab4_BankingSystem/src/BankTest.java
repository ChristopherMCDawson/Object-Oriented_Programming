
/*
 * Main driver class to call on classes and their extends and menus as well as loops for bank name request
 * and accounts number for said bank. Also holds the system scanner and the options menu for accounts , monthly updates and displaying
 * and finally Exiting the program.
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
import java.util.Scanner;// scanner import

/**
 * Assessment: Student Name: Christopher Decarie-Dawson Due:7/11/2021
 * Done:7/9/2021 prof: James.M
 **/

public class BankTest {// START

	/**
	 * The main method the power house of the Banking system , pulling everything
	 * together.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);// Scanner instance for the whole system!
		int choice;// local choice for menu

		System.out.print("Enter the name of the bank: ");// requests user input for bank name.
		String name = input.next();
		System.out.print("how many account holders do you have: ");// requests number of accounts in bank
		int numAccounts = input.nextInt();
		Bank b = new Bank(name, numAccounts);// creates a new bank instance with name and number of accounts.

		do {// feeds the menu to the user looping the system until 4 is entered to exit.
			System.out.print("1. Read Accounts\n" + "2. Run monthly process\n" + "3. Display accounts\n" + "4. Exit\n"
					+ "Enter your option: ");
			choice = input.nextInt();

			switch (choice) {// switch case to call systems by input requests from user.
			case 1:
				b.readAccounts(input);
				break;
			case 2:
				b.runMonthlyProcess();
				break;
			case 3:
				b.displayAccounts();
				break;
			case 4:
				System.out.print("Goodbye... have a nice day");// printed when the system is shut down
				break;
			default:// Error messaging !!
				System.out.println("Invalid entry" + "... please try again!");
			}

		} while (choice != 4);// loops while not 4
		input.close();// closes the scanner to the outside world
	}

}// END
