// TODO: Auto-generated Javadoc
/*
 *An extended class to Account class which adds a increasing interest rate to the
 * Savings account per month set at a rate of 3.99 , updating the balance with each increase monthly
 * and adapting to the increase of said balance.
 *
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
 * Assessment:lab 4 Student Name: Christopher Decarie-Dawson Due:7/11/2021
 * Done:7/9/2021 prof: James.M
 **/

public class Savings extends Account {// START

	/** The interest rate set as a double. */
	double interestRate;// interest rate variable

	/**
	 * Instantiates a new savings account interest rate.
	 */
	Savings() {
		interestRate = 3.99;
	}

	/**
	 * Updates balance per month on request.
	 */
	@Override
	public void updateBalance() {// Overrides the update balance for savings accounts with interest rate
		balance = ((balance * (interestRate / 12))) / 100 + balance;// the interest rate modifier .

	}

}// END
