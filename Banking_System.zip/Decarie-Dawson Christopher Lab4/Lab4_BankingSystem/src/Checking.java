
/*
 * An Extended class on to Account to add checking class variables to the account class. As well
 * Overriding the balance for monthly fee deductions.
 *
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
/**
 * Assessment:lab4 Student Name: Christopher Decarie-Dawson Due:7/11/2021
 * Done:7/9/2021 prof: James.M
 **/

public class Checking extends Account {// Start

	/** The fees as a double Variable. */
	double fees;

	/**
	 * Instantiates a new checking setting the fees to 13.50 per month.
	 */
	Checking() {// sets fee for monthly change
		fees = 13.50;
	}

	/**
	 * Update balance per month due to fees for a checking account.
	 */
	@Override
	public void updateBalance() {// overides the balance to subtract the monthly fee
		balance -= fees;

	}

}// END
