/*
 * An Abstract class that class offers added input for the bank class to take in account number and balance
 * as well a display account info 
 * 
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
import java.util.Scanner;// Scanner import

// TODO: Auto-generated Javadoc
/**
*Assessment:lab4
*Student Name: Christopher Decarie-Dawson
* Due:7/11/2021 	Done:7/9/2021
*prof: James.M
**/

public  abstract class Account {//START
	
	/** The account as long number. */
	long accNumber;// Account number as long
	
	/** The account holder object call. */
	Person accHolder = new Person();// create a Person object to use in this abstract class
	
	/** The balance of the account. */
	double balance;// Holds Account balance
	
	
	/**
	 * Reads account details such as account number and Balance. Calls on Person object for person info.
	 *
	 * @param in  The Scanner input from the driver class
	 */
	public void readAccountDetails(Scanner in) {// reads the accountDetails and uses driver class scanner, adds to info from person
		System.out.print("Enter account number: ");//requests account number
		accNumber = in.nextLong();//enters account number as a long
		accHolder.readPersonalDetails(in);//calls on the person object to fill in person data
		System.out.print("Enter balance: ");// requests balance as a double
		balance = in.nextDouble();// enters Balance
		
	}
	
	/**
	 * Display account information in required format using printf.
	 */
	public void displayAccount() {//places variables into printing format
		System.out.printf("       %3d  |     %10s  |   %14s  |        %6d  |     %,4.2f\n   ", accNumber,
				accHolder.getFullName(), accHolder.getEmail(),
				accHolder.getPhoneNumber(),balance);
		
	}
	
	/**
	 * Update balance for the run monthly process option.
	 */
	public abstract void updateBalance();// lets balance update per month



}//END
