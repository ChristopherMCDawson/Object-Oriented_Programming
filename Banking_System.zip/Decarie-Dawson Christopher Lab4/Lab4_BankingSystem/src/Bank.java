
/*
 * Bank class that  holds the account Arraylist and bank name for the system and 
 * lets the system make accounts. holds the sub menu for account options using a switch case.
 * Which also holds and calls on the classes and methods for monthly procresses check and display of accounts.
 * Also holds the final eye candy formating for the print out account info.
 * 
 *
 *@author Christopher Decarie-Dawson
 *@version 1.0
 *@since 1.8
 */
import java.util.ArrayList;// Arraylist import
import java.util.Scanner;//Scanner import

/**
 * Assessment:Lab4 Student Name: Christopher Decarie-Dawson Due:7/11/2021
 * Done:7/9/2021 prof: James.M
 **/

public class Bank {// Start

	/** The bank name variable holder. */
	static String bankName;// holds bank name in a static string

	/** The accounts Array list that will hold refences to objects. */
	ArrayList<Account> accounts;// Array list for account/ accounts

	/**
	 * Instantiates a new bank requesting bank name input and creating a new array
	 * number instance.
	 *
	 * @param name        the name of the bank
	 * @param numAccounts the num accounts in the new bank in the new array digit
	 */
	Bank(String name, int numAccounts) {// creates a bank with a name and number of accounts
		bankName = name;
		accounts = new ArrayList<>(numAccounts);// the new bank array in the arraylist
	}

	/**
	 * Reads accounts info request options to be selected , checking or savings
	 * using a switch statment throwing an error message if invalid input is
	 * entered. It also adds the account types to the array.
	 *
	 * @param in the in
	 */
	public void readAccounts(Scanner in) {// takes user input for account types.
		System.out.print("1. Checking\n" + "2. Savings\n" + "Enter the type of account you want to create: ");// prints
																												// options
																												// to
																												// user
		int option = in.nextInt();// takes selection

		switch (option) {// runs selection into switch case
		case 1:
			Account c = new Checking();// Creates a new checking account instants on the array on the array list.
			accounts.add(c);
			c.readAccountDetails(in);// Calls on the readAccountDetails for user input.
			break;
		case 2:
			Account s = new Savings();// Creates a new savings account instants on the array on the array list.
			accounts.add(s);
			s.readAccountDetails(in);// Call on the readAccountDetails for user input.
			break;
		default:
			System.out.println("Invalid input try again");// prints if an error input is input and resets the switch for
															// input.

		}
	}

	/**
	 * Runs monthly process by checking for accounts and then running the account
	 * updates to the accounts ,depending on the account types.
	 */
	public void runMonthlyProcess() {
		if (accounts.isEmpty()) {// checks for accounts
			System.out.println("No accounts to process");// error message thrower
		} else {
			for (Account num : accounts) {// updates the account balance on the number of accounts
				num.updateBalance();
			}
		}

	}

	/**
	 * Display accounts by checking if there are accounts and throwing an error
	 * message if there isn't.Will call on printTitle for bank and account details.
	 */
	public void displayAccounts() {
		if (accounts.isEmpty()) {// Error check
			System.out.println("No accounts to display");
		} else {
			printTitle();// prints title in formating
			for (Account num : accounts) {// calls the accounts and their displys
				num.displayAccount();
			}
		}

	}

	/**
	 * Prints the star pattern for the menu system.
	 */
	public static void printStar() {
		for (int i = 0; i <= 99; i++) {// 100 stars
			System.out.print("*");// *
		}
		System.out.println();// clears the input stream
	}

	/**
	 * Prints the title and formating eye candy along with information structures.
	 */
	public static void printTitle() {// End output menu displaying inputs and accounts formating
		printStar();// stars!
		System.out.println("\t\t\t\t\t\t" + bankName + "'s Bank");// bank name centering
		printStar();// stars!
		System.out.println("Acc Number  |             Name  |            Email  |   Phone Number  |     Balance  ");// info
																													// formating
		printStar();// stars!!
	}

}// END
