/**
*Assessment:lab2
*Student Name: Christopher Decarie-Dawson
* Due:6/6/2021 	Done:
*prof: James.M
**/

import java.util.Scanner;

public class Contractor extends Employee { // sub extends super//Start
	
	
	
	// instance variables
	private double hourlyRate;
    private double numHours;  
 
    
    
    
    @Override

    public void readEmployee() {// Reads from the Employee class and overrides asking for Hourly rate and hours worked  as well
        Scanner input = new Scanner(System.in);
        
        super.readEmployee();
        
        System.out.print("Enter Hourly Rate :");// output
        
        hourlyRate = input.nextDouble();
        
        
        System.out.print("Enter hours worked :");// output
        numHours = input.nextDouble();
        input.nextLine();
       
    } 
    @Override
    
    public void printEmployee() {// Reads and overrides the employee print and adds salary for contractor
    	double salary = hourlyRate*numHours;
        super.printEmployee();      
        System.out.printf("%,7.2f  |%n", salary);// output
    }
}
