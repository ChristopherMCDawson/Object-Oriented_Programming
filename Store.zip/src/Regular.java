/**
*Assessment:lab2
*Student Name: Christopher Decarie-Dawson
* Due:6/6/2021 	Done:
*prof: James.M
**/
import java.util.Scanner;

public class Regular extends Employee {// sub extends super //Start

	// variables
	private double salary;	
	


		
	@Override
	
	public void readEmployee() {// reads info from employee and adds Salary to data
		Scanner input = new Scanner(System.in);
		super.readEmployee();
		System.out.print("Enter salary: ");// output
		salary = input.nextDouble()/12;
		
		input.nextLine();	
	}	
	@Override
	
	public void printEmployee() {// Reads the info from the Employee and adds salary formatting
		super.printEmployee();
		System.out.printf("%,7.2f |%n", salary);// output
}
}