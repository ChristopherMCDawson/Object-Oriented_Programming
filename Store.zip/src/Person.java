/**
*Assessment:lab2
*Student Name: Christopher Decarie-Dawson
* Due:6/6/2021 	Done:
*prof: James.M
**/

public class Person {//Start
	
	
// instance variables
	private String first;
	
	private String last;
	
	private String email;
	
	private Long phone;
	
	// no arg
	public Person () {
		
	}
	//Constructor
	public Person (String first, String last, String email, Long phone) {
		this.first = first;
		this.last = last;
		this.email = email;
		this.phone = phone;
	}
	//getters
	public String getName() {
		return first +" "+last;
	}
	public String getEmail() {
		return email;
	}
	public Long getPhone() {
		return phone;
	}
}
