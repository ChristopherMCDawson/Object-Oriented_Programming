/**
*Assessment:lab2
*Student Name: Christopher Decarie-Dawson
* Due:6/6/2021 	Done:
*prof: James.M
**/
import java.util.Scanner;



public class Store {//Start

	
	private Employee[] employees;
	
	public Store(int numEmployee) {// Creates input nummber of Employee instances
		employees = new Employee[numEmployee];
	}
	
	
	public void readEmployeeDetails(){
		for(int i=0; i < employees.length;i++) {
			int choice;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter details of employee " + (i+1));// output
		System.out.println("1.Regular \n2.Constractor");// output
		System.out.print("Enter employee type: ");// output
		choice = input.nextInt();
		input.nextLine();
		
		switch(choice) {// choice switch for regular or contactor
			case 1:
				employees[i]= new Regular();//creates regular array
				employees[i].readEmployee();
				break;
			case 2:
				employees[i]= new Contractor();//creates contractor array
				employees[i].readEmployee();
				break;
			default:
				System.out.println("Invalid Input");// output
			}
		}
	}
	public void printEmployeeDetails() {// prints the Employee details depending on the info entered and type picked
		for(int i=0;i<employees.length;i++) {
			employees[i].printEmployee();
		}
	}
	// Menu Formating
	public static void printLine() {
		for(int i = 0; i < 80; i++) {
		System.out.print("=");// output
		
		}
		System.out.println();
	}
	// Menu Formating
	public static void printTitle(String storeName) {
		printLine();
		System.out.printf("\t\t\t%s Store Management System\t\t\t\t\t\n", storeName);
		printLine();
		 System.out.println("Emp#     |       Name        |       Email       | Phone Number |  Salary |");
		printLine();
	    }
	}
