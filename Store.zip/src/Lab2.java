/**
*Assessment:lab2
*Student Name: Christopher Decarie-Dawson
* Due:6/6/2021 	Done:
*prof: James.M
**/

import java.util.Scanner;

public class Lab2 {//Start

	
	public static void main(String[] args) {
		
		
		Scanner input = new Scanner(System.in);// scanner

		// instance variables
		String storeName;
		
		int numEmployees;
		
		System.out.print("Enter the name of the store: ");
		storeName = input.nextLine();
		
		System.out.print("Number of employees are in the store:  ");
		numEmployees = input.nextInt();
		
		Store store = new Store(numEmployees);// Creating store instance
		store.readEmployeeDetails();//calling Employee to fill details
		store.printTitle(storeName);//calling Store to print menu
		store.printEmployeeDetails();//calling arrays to print employee details
		
	}

}
