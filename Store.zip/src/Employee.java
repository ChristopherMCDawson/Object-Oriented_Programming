/**
*Assessment:lab2
*Student Name: Christopher Decarie-Dawson
* Due:6/6/2021 	Done:
*prof: James.M
**/
import java.util.Scanner;

public class Employee {//Start

	
	// instance variables
	private int employeeNumber;
    private Person emp;
    //no arg
    public Employee() {
    }
    // overloaded
    public Employee(int employeeNumber, String first, String last, String email, long phone) {
        emp = new Person(first, last, email, phone);// calling person to fill in None Employee info
        this.employeeNumber = employeeNumber;// adding EmployeeNumber to the file
    }
    //employee constructure
    public Employee(int numberOfEmployees) {
    }
    // read method
    public void readEmployee() {//Entering info about Employees
        Scanner input = new Scanner(System.in);//scanner
        System.out.print("Enter employee number: ");// output
        employeeNumber = input.nextInt();
        
        System.out.print("Enter first name: ");// output
        String first = input.next();
        
        System.out.print("Enter last name: ");// output
        String last = input.next();
        
        System.out.print("Enter email: ");// output
        String email = input.next();
        
        System.out.print("Enter phone number: ");// output
        long phone = input.nextLong();
        input.nextLine();

        emp = new Person(first, last, email, phone);
        this.employeeNumber = (int) employeeNumber;
    }
    public void printEmployee() {// Formating employee info for printout
        System.out.printf("%9d|%19s|%19s|%14d|",// output
                employeeNumber,
                emp.getName(),
                emp.getEmail(),
                emp.getPhone());
        		
    }
}
