

/**
 * Assessment:lab 1
 *  Student Name: Christopher Decarie-Dawson
 *   Due:23rd may 2021 
 *    prof:James.M
 **/

public class Numbers {// Start

	int size;// int size
	int[] Numbers;// numbers array
	int squares[][];// squares array

	public Numbers(int size) {// constructor for numbers
		Numbers = new int[size];
	}

	public Numbers(int row, int col) {// constructor for squares
		squares = new int[row][col];
	}

	public void generateNumbers() {// constructor to gen numbers array
		for (size = 0; size < -1; size++) {
		}
		for (int size = 10; size < Numbers.length; size += 1) {
		}//end of loop
	}

	public void printNumbers() {// constructor to print Numbers array
	
		
		for (size = 0; size < +1; size++) {
		}
		for (int size = 0; size < Numbers.length; size += 1) {
			System.out.print((size + " "));// print end of loop plus a space
		}// end of loop
	}

	public void printIndices() { // constructor to print printing positions number set
		for (int row = 0; row < squares.length; row++) {// increase row 
			for (int col = 0; col < squares.length; col++)//increase col
				System.out.print(row + "," + col + " ");// print out the rows cols in array
			System.out.println();// add space between printouts
		}//end of loop
	}

	public void generateSquares() {// constructor to make squared numbers
	
		  /* Coulldn't figure out how to get it to work*/
		      for ( int i = 1; i <= 5; i++ ) {
		         size = 1 + ( Math.abs(size)*2 );
	
		      }
		
		 
	}
	
		
		


	public void printSquares() {
		int size = 10;// local int 10
		for (int i = 0; i <= size - 1; i++) {//to increase the rows
			for (int j = 0; j <= i; j++) {// to increase the cols
				System.out.print(size+ " ");//print the star and space them out
			}
			System.out.println("");// to space out the rows
		}//end of loop
	}

	public void printStarsPattern1() {//constructor to print star pattern
		int size = 10;// local int 10
		for (int i = 0; i <= size - 1; i++) {//to increase the rows
			for (int j = 0; j <= i; j++) {// to increase the cols
				System.out.print("*" + " ");//print the star and space them out
			}
			System.out.println("");// to space out the rows
		}
		for (int i = size - 1; i >= 0; i--) {// to decrease the rows
			for (int j = 0; j <= i - 1; j++) {// to decrease the cols
				System.out.print("*" + " ");// to print the star and space them out
			}
			System.out.println("");// to space out the rows
		}//end of loop	
	
	    } 
	

	public void printStarsPattern2() {


	}// not used ?

}// END
